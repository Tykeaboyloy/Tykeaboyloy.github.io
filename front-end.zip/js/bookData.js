
// //show book informations on home page

//   bookInfor=JSON.parse(localStorage.getItem("books"))
//   console.log(bookInfor);
//   var getElement = document.getElementsByClassName("pic")[0];
//   bookInfor.map((item) => {
//     getElement.innerHTML =
//       getElement.innerHTML +
//       `
//           <div class="hi">
//               <a href="../html/bookDetail.html" target="_blank"> <img src="${item.bookLink}" alt="book"></a>
//               <h4>Title: ${item.bookTitle}</h4>
//               <span>Author: ${item.bookAuthor}</span><br>
//               <span><b style="color:red;">Price from : ${item.bookPrice}</b></span>
//           </div>
//     `;
//   });
  
